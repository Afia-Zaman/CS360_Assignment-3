#include <stdio.h>             // Include standard input/output header for C
#include <iostream>            // Include the input/output stream library for C++
using namespace std;           // Use the standard namespace to avoid prefixing std::

class A {                      // Define a class named A
public:
    A();                       // Declare a default constructor
    A(int);                    
    A(const A&);               // Declare a copy constructor
    ~A();                      // Declare a destructor
public:
    void operator=(const A& rhs); // Declare a copy assignment operator
    void Print();              // Declare a non-const member function to print x
    void PrintC() const;       // Declare a const member function to print x
    int x;                     // Declare an integer member variable x
public:
    int& X() { return x; }     // Define a member function X() that returns a reference to x
};


A::A() : x(0)                 // Define the default constructor with member initializer for x to 0
{
    cout << "Hello from A::A() Default constructor" << endl;
}

A::A(int i) : x(i)            // Define the constructor that sets x to the provided integer value
{
    cout << "Hello from A::A(int) constructor" << endl;
}

A::A(const A& a) : x(a.x)     // Define the copy constructor that copies x from another object
{
    cout << "Hello from A::A(const A&) constructor" << endl;
}

A::~A()                       // Define the destructor
{
    cout << "Hello from A::A destructor" << endl;
}

void A::operator=(const A& rhs) // Define the copy assignment operator
{
    x = rhs.x;
    cout << "Hello from A::operator=" << endl;
}

void A::Print()               // Define Print() that outputs the value of x
{
    cout << "A::Print(), x " << x << endl;
}

void A::PrintC() const        // Define PrintC(), a const version that also prints the value of x
{
    cout << "A::PrintC(), x " << x << endl;
}

void PassAByValue(A a)        // Define a function that takes an object of A by value
{
    cout << "PassAByValue, a.x " << a.x << endl;
    a.x++;                     // Modify the copy of a
    a.Print();                 // Print using the modified copy
    a.PrintC();                // Print using the modified copy in const context
}

void PassAByReference(A& a)   // Define a function that takes an object of A by reference
{
    cout << "PassAByReference, a.x " << a.x << endl;
    a.x++;                     // Modify the original a
    a.Print();                 // Print using the modified original
    a.PrintC();                // Print using the modified original in const context
}

void PassAByConstReference(const A& a) // Define a function that takes an object of A by const reference
{
    cout << "PassAByReference, a.x " << a.x << endl;
    a.PrintC();                // Print in const context
    // a.Print();              // This would cause a compiler error since a is const
}

void PassAByPointer(A* a)     // Define a function that takes a pointer to an object of A
{
    cout << "PassAByPointer, a->x " << a->x << endl;
    a->x++;                    // Modify the original a through the pointer
    a->Print();                // Print using the pointer
    a->PrintC();               // Print using the pointer in const context
}

int main()                    
{
    cout << "Creating a0"; getchar(); // Prompt and wait for input before constructing a0
    A a0;                     // Create an object of A using the default constructor

    cout << "Creating a1"; getchar(); 
    A a1(1);                  // Create an object of A with the value 1 using the parameterized constructor

    cout << "Creating a2"; getchar(); 
    A a2(a0);                 // Create an object of A by copying a0

    cout << "Creating a3"; getchar(); 
    A a3 = a0; // Use copy constructor to initialize a3 with the state of a0

    cout << "Assigning a3 = a1"; getchar(); 
    a3 = a1; // Use copy assignment operator to assign a1's state to a3

    // Call some of the "A" subroutines
    cout << "PassAByValue(a1)"; getchar(); 
    PassAByValue(a1); // Call PassAByValue, which passes a1 by value (a copy is made)

    cout << "After PassAByValue(a1)" << endl; 
    a1.Print(); // Print current state of a1 

    cout << "PassAByReference(a1)"; getchar();
    PassAByReference(a1); // Call PassAByReference, which passes a1 by reference 

    cout << "After PassAByReference(a1)" << endl; 
    a1.Print(); // Print current state of a1 

    cout << "PassAByConst(a1)"; getchar(); 
    PassAByConstReference(a1); // Call PassAByConstReference, which passes a1 by const reference 

    cout << "After PassAByConstReference(a1)" << endl; 
    a1.Print(); // Print current state of a1 
    cout << "PassAByPointer(&a1)"; getchar(); 
    PassAByPointer(&a1); // Call PassAByPointer, which passes the address of a1 

    cout << "After PassAByPointer(a1)" << endl; 
    a1.Print(); // Print current state of a1 
// 
    cout << "a1.X() = 10"; getchar(); 
    a1.X() = 10; // Set the value of a1's member variable x to 10 via the X() function

    a1.Print(); // Print current state of a1 to see the updated value of x

    cout << "PassAByConstReference"; getchar(); 
    PassAByConstReference(20); // Call PassAByConstReference with a temporary object created from integer 20

    // Here, PassAByConstReference is called with the literal 20. The reason this compiles is that in C++, 
    // you can pass a literal or a non-const rvalue to a function that expects a const reference parameter.
    // When this happens, the compiler creates a temporary object of type A using the constructor A(int) that 
    // takes the literal 20 as an argument. The temporary object lives until the end of the function call, allowing 
    // the PassAByConstReference to access the temporary object's member variable x, which is set to 20.
    
    return 0;
    
}
