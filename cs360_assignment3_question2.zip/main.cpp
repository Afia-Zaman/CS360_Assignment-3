#include <iostream>
#include <string>
using namespace std;

class Student {
protected:
    int studentNumber;
    string studentName;
    double studentAverage;

public:
    Student() : studentNumber(0), studentName(""), studentAverage(0.0) {}

    void setStudentNumber(int num) { studentNumber = num; }
    int getStudentNumber() const { return studentNumber; }

    void setStudentName(string name) { studentName = name; }
    string getStudentName() const { return studentName; }

    void setStudentAverage(double avg) { studentAverage = avg; }
    double getStudentAverage() const { return studentAverage; }

    void print() const {
        cout << "Student Number: " << studentNumber
             << "\nStudent Name: " << studentName
             << "\nStudent Average: " << studentAverage << endl;
    }
};

class GraduateStudent : public Student {
protected:
    int level;
    int year;

public:
    GraduateStudent() : level(0), year(0) {}

    void setLevel(int lvl) { level = lvl; }
    int getLevel() const { return level; }

    void setYear(int yr) { year = yr; }
    int getYear() const { return year; }

    void print() const {
        Student::print();
        cout << "Level: " << level << "\nYear: " << year << endl;
    }
};

class Master : public GraduateStudent {
private:
    int newId;

public:
    Master() : newId(0) {}

    void setNewId(int id) { newId = id; }
    int getNewId() const { return newId; }

    void print() const {
        GraduateStudent::print();
        cout << "New ID: " << newId << endl;
    }
};

int main() {
    Student student;
    student.setStudentNumber(123);
    student.setStudentName("Afia Zaman");
    student.setStudentAverage(89.5);
    cout << "Student Information:" << endl;
    student.print();

    Master master;
    master.setStudentNumber(456);
    master.setStudentName("Naim Rahman");
    master.setStudentAverage(91.2);
    master.setLevel(2);
    master.setYear(2022);
    master.setNewId(7890);
    cout << "\nMaster Student Information:" << endl;
    master.print();

    return 0;
}
